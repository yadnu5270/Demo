package com.example.yadnuu.room;


import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class Result extends AppCompatActivity {

    public TextView textinfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        textinfo = findViewById(R.id.tx);

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {

              List<User> users =  Dash.getMdataBase(getApplicationContext()).userDAO().getUsers();
                String info = "";

                if (users != null) {
                    for (User usr : users) {
                        int id = usr.getId();
                        String name = usr.getName();
                        String phone = usr.getPhon();
                        String email = usr.getEmail();
                        info = info + "\n\n id : " + id + "\n name : " + name + "\n Number" + phone + "\n E-mail" + email;
                    }
                    textinfo.setText(info);

                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                        }
                    });

                }

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();

        if (id== android.R.id.home){
            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }
}



