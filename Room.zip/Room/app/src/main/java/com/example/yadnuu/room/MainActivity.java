package com.example.yadnuu.room;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    private EditText Edit2,Edit,Edit3;
    private Button submit;
    final User user = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        Edit = (EditText)findViewById(R.id.editText);
        Edit2 = (EditText)findViewById(R.id.editText2);
        Edit3 = (EditText)findViewById(R.id.editText3);
        submit = (Button)findViewById(R.id.button);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Subm();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();

        if (id== android.R.id.home){
            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void Subm()
    {

        String edit2 =Edit2.getText().toString();
        String edit = Edit.getText().toString();
        String edit3 = Edit3.getText().toString();

        user.setName(edit);
        user.setPhon(edit2);
        user.setEmail(edit3);

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {

                Dash.getMdataBase(getApplicationContext()).userDAO().adduser(user);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this,"Submitted",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this,Dash.class);
                    startActivity(intent);

                }
            });
                user.setName("");
                user.setEmail("");
                user.setPhon("");

            }
        });


            }
}
