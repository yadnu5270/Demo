package com.example.yadnuu.room;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Dash extends AppCompatActivity {
    private Button add,disp,dll2,uu2;

    private static MyDataBase mdataBase;
    private static final String DATABASE_NAME ="userdb";
    public static MyDataBase getMdataBase(Context context){
        if (mdataBase==null){
            mdataBase= Room.databaseBuilder(context,MyDataBase.class,DATABASE_NAME).allowMainThreadQueries().build();
        }
        return mdataBase;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash);


        dll2=(Button)findViewById(R.id.dl2);
        dll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dash.this,Deletee.class);
                startActivity(intent);
            }
        });

        uu2=(Button)findViewById(R.id.u2);
        uu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dash.this,Updatee.class);
                startActivity(intent);
            }
        });

        add =(Button)findViewById(R.id.ada);
        disp=(Button)findViewById(R.id.geta);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dash.this,MainActivity.class);
                startActivity(intent);
            }
        });
        disp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Dash.this,Result.class);
                startActivity(intent);
            }
        });
    }
}
