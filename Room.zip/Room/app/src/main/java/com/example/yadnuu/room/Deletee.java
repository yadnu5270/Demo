package com.example.yadnuu.room;

import android.arch.persistence.room.Delete;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Deletee extends AppCompatActivity {

    private Button del;
    private EditText et;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deletee);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        et =findViewById(R.id.edtx);
        del=findViewById(R.id.bt2);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        int a= Integer.parseInt(et.getText().toString());
                        User user=new User();
                        user.setId(a);
                        Dash.getMdataBase(getApplicationContext()).userDAO().deleteUser(user);

                    }
                });
                Toast.makeText(Deletee.this,"Data Deleted",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Deletee.this,Dash.class);
                startActivity(intent);

            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();

        if (id== android.R.id.home){
            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
