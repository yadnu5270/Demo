package com.example.yadnuu.room;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Updatee extends AppCompatActivity {
    private Button fetch,upd;
    private EditText Editname,Editphone,Editemail,Editid;
    private TextView t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updatee);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        t1=(TextView)findViewById(R.id.textView);
        t2=(TextView)findViewById(R.id.textView3);
        t3=(TextView)findViewById(R.id.textView4);
        t1.setVisibility(View.INVISIBLE);
        t3.setVisibility(View.INVISIBLE);
        t2.setVisibility(View.INVISIBLE);
        Editname=(EditText) findViewById(R.id.ename);
        Editphone=(EditText) findViewById(R.id.ephone);
        Editemail=(EditText) findViewById(R.id.eemail);
        Editname.setVisibility(View.INVISIBLE);
        Editemail.setVisibility(View.INVISIBLE);
        Editphone.setVisibility(View.INVISIBLE);
        upd=(Button)findViewById(R.id.up2);
        upd.setVisibility(View.INVISIBLE);
        fetch=(Button)findViewById(R.id.F2);
        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search(((EditText)findViewById(R.id.et4)).getText().toString());
            }
        });
        upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AsyncTask.execute(new Runnable() {                               //Upload code
                    @Override
                    public void run() {
                        User uer = new User();

                        Editid = (EditText) findViewById(R.id.et4);

                        int idd=Integer.parseInt(Editid.getText().toString());
                        String phonee = Editphone.getText().toString();
                        String namee = Editname.getText().toString();
                        String emaile= Editemail.getText().toString();
                        uer.setId(idd);
                        uer.setName(namee);
                        uer.setEmail(emaile);
                        uer.setPhon(phonee);

                        Dash.getMdataBase(getApplicationContext()).userDAO().updateUser(uer);

                       runOnUiThread(new Runnable() {
                           @Override
                           public void run() {
                               Toast.makeText(getApplicationContext(),"Updated succesfully",Toast.LENGTH_SHORT).show();

                               Intent intent = new Intent(Updatee.this,Dash.class);
                               startActivity(intent);

                           }
                       });

                    }
                });

            }
        });

        }
        private void search(final String ref)
        {

            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    final User user = Dash.getMdataBase(getApplicationContext()).userDAO().findData(ref);
                    if(user!=null)
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                t1.setVisibility(View.VISIBLE);
                                t3.setVisibility(View.VISIBLE);
                                t2.setVisibility(View.VISIBLE);
                                upd.setVisibility(View.VISIBLE);
                                Editname.setVisibility(View.VISIBLE);
                                Editemail.setVisibility(View.VISIBLE);
                                Editphone.setVisibility(View.VISIBLE);

                                Editname.setText(user.getName());
                                Editphone.setText(user.getPhon());
                                Editemail.setText(user.getEmail());

                            }
                        });
                    else
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(),"Not found",Toast.LENGTH_SHORT).show();
                                t1.setVisibility(View.INVISIBLE);
                                t3.setVisibility(View.INVISIBLE);
                                t2.setVisibility(View.INVISIBLE);
                                Editname.setVisibility(View.INVISIBLE);
                                Editemail.setVisibility(View.INVISIBLE);
                                Editphone.setVisibility(View.INVISIBLE);
                                upd.setVisibility(View.INVISIBLE);
                            }
                        });
                }
            });
        }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();

        if (id== android.R.id.home){
            this.finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
